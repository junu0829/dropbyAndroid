package com.akj.dropby

class ItemData {
    var docId: String? = null
    var email: String? = null
    var content: String? = null
    var date: String? = null
}